/*:
 # Weather Prediciton Playground Using CoreML
 ### Simple playground that predicts the current weather in 5 cities.
 
 Created By Mohamed Salah
 ****
 
 ## Idea and Concept
 **GIVE ME DATA AND I WILL GIVE YOU THE FUTURE.** \
 First of all let me be clear, the idea of predicting weather can never be accurate using machine learning because to predict weather accurately you must use special accurate weather gauges. However, we still can predict, to some limits, the current weather by feeding ML models with previous weather data. And remember, `Playground`: Noun, a place where people can play!
 
 Analyzing historical weather, I noticed an interesting pattern: the same date every year have 40-70% probability of being the same temperature, and if it's not the same then it will be 1-5 degrees difference at maximum. Additionally, other weather values including dewpoint, pressure, or wind speed are largely dependant on the main air temperature. By using this pattern, I was able to put my hypothesis into action. And the best way to test my hypothesis is using the best Machine Learning Framework: [CoreML](https://developer.apple.com/documentation/coreml). Let me be honest, when [CoreML](https://developer.apple.com/documentation/coreml) was first introduced I was confused not because how I implement it, but because the ability to create custom models was vague. Nevertheless, last year when [CreateML](https://developer.apple.com/documentation/createml) was introduced everything went smooth. AND I REALLY LOVE IT!!
 
 ## How This Playground Works
 - The models are first trained using [CreateML](https://developer.apple.com/documentation/createml): Temperature is predicted using a classifier, and other values are predicted through a regressor object.
 - The UI responsible for viewing predicted values is created.
 - The Weather object is then predicted using `PredictionUtils` class: Temperature is first predicted using a date, and other values are built on each other starting from temperature.
 - The UI is refreshed with predicted Weather objects.
 
 ## Prediction Accuracy
 As I mentioned above, predicting accurate weather using machine learning is quite impossible. However, we can build predictions over previous weather data. So what are the odds? During evaluation of the trained models, I can confirm that 55% of the time the predictions were quite identical to the real weather information. The other 45% have from 1-5 degrees difference from actual temperature.
 ### The worst distance between predictions and the actual values
 - Temperature: 7°C
 - Pressure: 12 hPa
 - Wind Speed: 2.6 m/s
 - Visibility: 4.1 km
 - Humidity: 15%
 
 - Note:
 Confidence is also included with each prediction varying from 40-99%.
 
 ## Playground Pages
 The project is separated into two main pages:
 ### Training a model
 Training a model is now made easy by the introduction of [CreateML](https://developer.apple.com/documentation/createml).
 - `You have a data file`
 - `You create a classifier or a regressor`
 - `You export the final model`
 
 **JUST LIKE THAT!!**\
 Everything is made by you for you, and you are not required to be a data scientist to perform these simple steps.
 - Important:
 **Training and generating a CoreML model requires a MacOS target playground, so this playgroundpage won't run; instead, it only shows you how the process is done.**
 
 ### Predicitng the weather
 This playgroundpage is responsible for generating a UI that will predict and give you the predicted weather, using graphs and other clean-designed components.
 You can predict weather in 5 cities:
 - `San Francisco`
 - `Hong Kong`
 - `Bangkok`
 - `Dubai`
 - `Cairo`
 
 You can always train models based on other cities datas, and you are ready to predict your best city's weather.
 
 ****
 [Train the Models](Train%20CoreML) | [Predict the Weather](Predict%20Weather)
 */
