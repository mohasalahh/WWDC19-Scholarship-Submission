/*:
 # Predicitng Weather UI
 ### PlaygroundPage that is responsible for showing predicted results.
 ****
 
 ## Sources Descriptions
 - `Constants` : manages static constants used across the playground.
 - `DaysCollectionView` : resposible for generating a [UICollectionView](https://developer.apple.com/documentation/uikit/uicollectionview) that is used to show the week days.
 - `Extensions` : manages global extensions that simplify things up.
 - `GraphTableView` : resposible for generating a [UITableView](https://developer.apple.com/documentation/uikit/uitableview) that is used to show Weather data over a graph.
 - `GraphView` : used to initlize and draw a line graph that is used in showing weather over hours.
 - `MainView` : used to initlize the main view that includes all the other views.
 - `PredictionUtils` : singleton class that manages predictions from [CoreML](https://developer.apple.com/documentation/coreml) models.
 - `SideBarTableView` : resposible for generating a [UITableView](https://developer.apple.com/documentation/uikit/uitableview) that is used to show available cities to predict.
 - `WeatherDataCollecionView` : resposible for generating a [UICollectionView](https://developer.apple.com/documentation/uikit/uicollectionview) that is used to show Weather data.
 
 ## View Hierarchy
 ````
 MainView->
   SideBarTableView->
     SideBarTableViewCell
 
   WeatherDataCollectionView->
     WeatherCollectionViewCell
 
   GraphTableView->
     GraphTableViewCell->
       GraphView
 
   DaysCollectionView->
     DaysCollectionViewCell
 ````
 */
// Start Date: 15/3/2019 06:05 PM
// End Date: 20/3/2019 08:42 PM

import UIKit
import PlaygroundSupport
/*:
 - Important:
 Predicitons are not 100% accurate as mentioned in the [first page](Table%20of%20Contents), so you are very likely to experience inaccurate predictions. However, Remember! Playground: Noun, a place where people can play!
 * Callout(Font License):
 Aleo Font is licensed under the SIL Open Font License, Version 1.1.
 - Note:
 The MainView is responsive so you can change the resolution.
 */
let mainView = MainView(height: 600)
PlaygroundPage.current.liveView = mainView
/*:
 - Note:
 I hope you enjoyed my playground. See you either in WWDC or who knows 🤷‍♂️. In either cases, I'm happy that I did something using CoreML; even if it's not accurate enough, I had fun doing it.
 ****
 [Table of Contents](Table%20of%20Contents) | [Training The Models](@previous)
 */
