//
//  Constants.swift
//  This class manages static constants used across the playground.
//
//  WWDC19
//
//  Created by Mohamed Salah on 15/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//

import Foundation

// Main weather object
struct Weather {
     let temp: Int /* °C */
     let probability: Int /* % */
     let humidity: Int /* % */
     let pressure: Int /* hPa */
     let visibility: Double /* km */
     let windSpeed: Double /* mps */
}

// Font weight
 enum FontWeight {
    case Regular
    case Bold
    
    var description : String {
        switch self {
        case .Regular:
            return "Regular"
        case .Bold:
            return "Bold"
        }
    }
}

/**
 Returns the specifc timeZone related to GMT.
 - parameters:
 - city: the specific city code
 */
 let cityTimezone = { (city: String) -> Int in
    switch city {
    case "CA":
        return 2
    case "SF", "SJ":
        return -7
    case "BA":
        return 7
    case "DU":
        return 4
    case "HK":
        return 8
    default:
        return 0
    }
}

/**
 Returns the full name of a specific city.
 - parameters:
 - city: the specific city code
 */
 let cityFullName = { (city: String) -> String in
    switch city {
    case "CA":
        return "Cairo"
    case "SF":
        return "San Francisco"
    case "SJ":
        return "San Jose"
    case "BA":
        return "Bangkok"
    case "DU":
        return "Dubai"
    case "HK":
        return "Hong Kong"
    default:
        return ""
    }
}
