//
//  DaysCollectionView.swift
//  This class is resposible for generating a CollectionView that is used to show the week days.
//
//  WWDC19
//
//  Created by Mohamed Salah on 16/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//

import UIKit

 class DaysCollectionView: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
     var timeZoneGMT = 0 {
        didSet {
            reloadData() // Reload the days when the timezone is changed
        }
    }
    var selected = 0
    
     init(frame: CGRect) {
        let m = UICollectionViewFlowLayout()
        super.init(frame: frame, collectionViewLayout: m)
        
        m.minimumInteritemSpacing = frame.height/8
        
        setCollectionViewLayout(m, animated: false)
        dataSource = self
        delegate = self
        backgroundColor = .clear
        
        register(DayCollectionViewCell.self, forCellWithReuseIdentifier: "cell")
    }
    required  init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
    
     func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
     func collectionView(_ collectionView: UICollectionView,
                               numberOfItemsInSection section: Int) -> Int {
        return 7
    }
    
     func collectionView(_ collectionView: UICollectionView,
                               cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! DayCollectionViewCell
        let row = indexPath.row
        
        let date = Date().addingTimeInterval(TimeInterval(row*86400)) // Getting the day of the week, while 1 day = 86400 secs
        let d = DateFormatter()
        d.dateFormat = "EEE" // Three letters day
        d.timeZone = TimeZone(secondsFromGMT: timeZoneGMT*3600) // 1 hour = 3600 secs
        
        cell.content.text = d.string(from: date)
        
        // Change the appearance of the selected day
        if selected == row {
            cell.content.textColor = .white
            cell.backgroundColor = .colorMainLight
        }else {
            cell.content.textColor = .colorMainLight
            cell.backgroundColor = .white
        }
        
        return cell
    }
    
     func collectionView(_ collectionView: UICollectionView,
                               layout collectionViewLayout: UICollectionViewLayout,
                               sizeForItemAt indexPath: IndexPath) -> CGSize {
        // The width of the collectionView is divided equally among the cells(without including the margins)
        return CGSize(width: (frame.width/CGFloat(collectionView.numberOfItems(inSection: 0)))-(frame.height/8), height: frame.height)
    }
    
    var update = true
     func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if selected != indexPath.row {
            let unselectedCell = collectionView.cellForItem(at: IndexPath(row: selected, section: 0)) as! DayCollectionViewCell
            let selectedCell = collectionView.cellForItem(at: indexPath) as! DayCollectionViewCell
            
            UIView.animate(withDuration: 0.3, delay: 0, options: [.curveEaseInOut], animations: {
                
                unselectedCell.content.textColor = .colorMainLight
                unselectedCell.backgroundColor = .white
                
                selectedCell.content.textColor = .white
                selectedCell.backgroundColor = .colorMainLight
                
            }, completion: nil)
            
            selected = indexPath.row
            
            (superview as! MainView).selectDay(days: selected)
        }
    }
    
    func resetSelection() {
        selected = 0
    }
}

class DayCollectionViewCell: UICollectionViewCell {
    
    var content: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let width = frame.size.width
        
        //Nothing interesting: designing the cell
        content = UILabel(frame: CGRect(x: width/15, y: width/15, width: width-((width/15)*2), height: width-((width/15)*2)))
        
        content.font = UIFont(name: "Aleo-Bold", size: width/3.3)
        content.textAlignment = .center
        
        layer.cornerRadius = width/3
        
        layer.borderWidth = width/22
        layer.borderColor = UIColor.colorMainLight.cgColor
        
        addSubview(content)
    }
    
    required  init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
}

