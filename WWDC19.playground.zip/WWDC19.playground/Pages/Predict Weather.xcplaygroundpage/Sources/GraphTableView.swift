//
//  GraphTableView.swift
//  This class is resposible for generating a TableView that is used to show Weather data over a graph.
//
//  WWDC19
//
//  Created by Mohamed Salah on 18/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//

import UIKit

 class GraphTableView: UITableView, UITableViewDelegate, UITableViewDataSource  {
    
    final let titles = ["Temperature", "Humidity"]
    final let units = ["°", "%"]
    
     var timeZoneGMT = 0
     var data = [[Double]]() {
        didSet {
            reloadData() // Reload the graph when data is updated
        }
    }
    
     init(frame: CGRect) {
        super.init(frame: frame, style: .plain)
        
        dataSource = self
        delegate = self
        
        separatorColor = .clear
        allowsSelection = false
        
        showsVerticalScrollIndicator = false
        isPagingEnabled = true
        
        layer.cornerRadius = frame.width/20
        clipsToBounds = true
        backgroundColor = .clear
        
        register(GraphTableViewCell.self, forCellReuseIdentifier: "cell")
    }
    required  init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! GraphTableViewCell
        let row = indexPath.row
        
        // Reload the graph with specific values, timezone, and title
        cell.graph.refresh(points: data[row], timeZone: timeZoneGMT, title: titles[row], unit: units[row])
        
        return cell
    }
    
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return frame.height-(frame.height/25)
    }
    
     func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        // Animating showing cell
        cell.alpha = 0
        UIView.animate(withDuration: 0.3, delay: 0, options: [.curveEaseInOut], animations: {
            cell.alpha = 1
        }, completion: nil)
    }
}

 class GraphTableViewCell: UITableViewCell {
    
    var graph: GraphView!
    
    override  init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        // Adding the GraphView to the cell
        graph = GraphView(frame: contentView.bounds)
        addSubview(graph)
    }
    
    var once = true
     override func layoutSubviews() {
        super.layoutSubviews()
        // Avoid resetting every time the view is refreshed
        if once {
            once = false
            graph.frame = contentView.bounds.inset(by: UIEdgeInsets(top: contentView.frame.height/24, left: 0, bottom: contentView.frame.height/24, right: 0))
            graph.layer.cornerRadius = graph.frame.width/20
        }
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
}
