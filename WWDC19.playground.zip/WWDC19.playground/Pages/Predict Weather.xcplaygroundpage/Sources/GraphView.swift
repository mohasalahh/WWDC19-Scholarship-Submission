//
//  GraphView.swift
//  This class is used to initlize and draw a line graph that is used in showing weather over hours.
//
//  WWDC19
//
//  Created by Mohamed Salah on 17/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//

import UIKit

class GraphView: UIView {
    
    var title = ""
    var unit = ""
    var timeZoneGMT = 0
    var points = [Double]() {
        didSet {
            setNeedsDisplay() // Redraw the view when the values is refreshed
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor(red: 93, green: 117, blue: 245)
        clipsToBounds = true
    }
    
    override func draw(_ rect: CGRect) {
        // Check for points availability
        if points.count > 0 {
            
            if points.allSatisfy({$0 == points.last}) {
                points[0] -= 1
            }
            
            // Margined dimensions
            let width = rect.width*0.85
            let height = rect.height*0.9
            
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .left
            
            var attributes: [NSAttributedString.Key : Any] = [
                .paragraphStyle: paragraphStyle,
                .font: UIFont(name: "Aleo-Bold", size: height/10)!,
                .foregroundColor: UIColor.white
            ]
            
            // Drawing the title
            NSAttributedString(string: title, attributes: attributes).draw(in: CGRect(x:
                rect.width*0.05, y: rect.height*0.08, width: width, height: height/5))
            
            paragraphStyle.alignment = .center
            attributes[.paragraphStyle] = paragraphStyle
            
            /**
             Returns the point of x in the original view.
             - parameters:
             - city: x value (eg. 1,2,3,4,5)
             */
            let pointX = { (num: Int) -> CGFloat in
                return (CGFloat(num)
                    * (width/CGFloat(self.points.count-1)))
                    // Add left margin
                    + (rect.width/2) - (width/2)
            }
            
            /**
             Returns the point of y in the original view.
             - parameters:
             - city: y value (eg. temperature)
             */
            let pointY = { (temp: Double) -> CGFloat in
                // Calculating a new point in the original view that must fits inside the view's bounds -+.
                // Took me 2 hours to figure it out !!
                return (height-((height/5)))-(CGFloat(temp-self.points.min()!) * ((height-((rect.height*0.1)+(height/3)+(height/4.5)))/CGFloat(self.points.max()!-self.points.min()!)))
            }
            
            let d = DateFormatter()
            d.dateFormat = "HH" // Only hours (24hrs format)
            d.timeZone = TimeZone(secondsFromGMT: timeZoneGMT*3600) // 1 hour 3600 secs
            
            let currentDate = Date()
            let currentHour = Int(d.string(from: currentDate))
            
            // Setting the fill color
            UIColor.white.setFill()
            
            var pointsXY = [CGPoint]()
            for i in 0..<points.count {
                // Appending final points related to original view.
                pointsXY.append(CGPoint(x: pointX(i), y: pointY(points[i])))
                
                let guideLine = UIBezierPath()
                guideLine.lineWidth = height/90
                
                // Drawing line
                guideLine.move(to: CGPoint(x: pointsXY[i].x-(height/90/2), y: 0))
                guideLine.addLine(to: CGPoint(x: pointsXY[i].x-(height/90/2), y: rect.height))
                
                // Stroking
                UIColor(white: 1, alpha: 0.1).setStroke()
                guideLine.stroke()
                
                // Adding points' circles
                UIBezierPath(ovalIn: CGRect(x: pointsXY[i].x-(height/28/2), y: pointsXY[i].y-(height/28/2), width: height/28, height: height/28)).fill()
                
                attributes[.font] = UIFont(name: "Aleo-Bold", size: height/13)!
                // Drawing point's temperature(Y Axis)
                NSAttributedString(string: String(Int(points[i]))+unit, attributes: attributes).draw(in: CGRect(x: pointsXY[i].x-(height/5/2), y: pointsXY[i].y-(height/5/1.5), width: height/5, height: height/5))
                
                attributes[.font] = UIFont(name: "Aleo-Bold", size: height/14)!
                
                // Check if the day is over
                var hour = currentHour!+i
                if hour > 23 {
                    hour -= 24
                }
                // Drawing time labels (X Axis)
                NSAttributedString(string: String(hour)+":00", attributes: attributes).draw(in: CGRect(x: pointsXY[i].x-(height/5/2), y: rect.height-(height/7), width: height/5, height: height/7))
                
            }
            
            // Generating curvy graph path.
            let graphPath = pointsXY.getCurvedFromStraight()
            graphPath.lineWidth = height/60
            
            // Semi-transparent shape below the graph line
            let shadowPath = graphPath.copy() as! UIBezierPath
            
            // Closing the orginal line path
            shadowPath.addLine(to: CGPoint(x: pointsXY[points.count-1].x, y: rect.height))
            shadowPath.addLine(to: CGPoint(x: pointsXY[0].x, y: rect.height))
            shadowPath.close()
            shadowPath.addClip()
            
            // Filling shadowPath
            UIColor(white: 1, alpha: 0.1).setFill()
            shadowPath.fill()
            
            // Stroking the graph line
            UIColor.white.setStroke()
            graphPath.stroke()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /**
     Refresh the graph with new data.
     - parameters:
     - points: the input data
     - timeZone: used in drawing the time (eg. x value)
     - title: the upper title in the graph
     - unit: the unit of the y values
     */
    func refresh(points: [Double], timeZone: Int, title: String, unit: String) {
        self.timeZoneGMT = timeZone
        self.title = title
        self.unit = unit
        self.points = points
    }
}
