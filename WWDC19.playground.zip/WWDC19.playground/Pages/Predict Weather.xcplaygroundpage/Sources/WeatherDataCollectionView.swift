//
//  WeatherDataCollectionView.swift
//  This class is resposible for generating a CollectionView that is used to show Weather data.
//
//  WWDC19
//
//  Created by Mohamed Salah on 16/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//

import UIKit

class WeatherDataCollectionView: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
    final let dataTitles = [["Pressure", "Wind Speed", "Visibility"], ["Humidity", "Confidence"]]
    var data = [[String]]() {
        didSet {
            reloadData() // Reload updated data the view when the values is refreshed
        }
    }
    
    init(frame: CGRect) {
        let m = UICollectionViewFlowLayout()
        m.minimumInteritemSpacing = 0
        super.init(frame: frame, collectionViewLayout: m)
        
        dataSource = self
        delegate = self
        backgroundColor = .clear
        
        register(WeatherDataCollectionViewCell.self, forCellWithReuseIdentifier: "cell")
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return data.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                               numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 3 // 3 rows in the first section
        }else {
            return 2 // 2 rows in the second section
        }
    }
    
    func collectionView(_ collectionView: UICollectionView,
                               cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! WeatherDataCollectionViewCell
        let row = indexPath.row
        let section = indexPath.section
        
        cell.content.text = data[section][row]
        cell.title.text = dataTitles[section][row]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                               layout collectionViewLayout: UICollectionViewLayout,
                               sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        // The size of one cell is equal to half the height and 3th the width of the CollectionView.
        // Although the width of the cell will usually be 3th the CollectionView, I'm using numberOfItems to give me more flexibility.
        return CGSize(width: frame.width/CGFloat(collectionView.numberOfItems(inSection: 0)), height: frame.height/2)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                               layout collectionViewLayout: UICollectionViewLayout,
                               insetForSectionAt section: Int) -> UIEdgeInsets {
        
        // Centering the last section
        if section == 1 {
            
            let totalCellWidth = (frame.width/CGFloat(collectionView.numberOfItems(inSection: 0))) * 2
            let inset = (frame.width - totalCellWidth) / 2
            
            return UIEdgeInsets(top: 0, left: inset, bottom: 0, right: inset)
        }else {
            return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        }
    }
}

import UIKit

class WeatherDataCollectionViewCell: UICollectionViewCell {
    
    var content: UILabel!
    var title: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let width = frame.size.width
        let height = frame.size.height
        
        //Nothing interesting: designing the cell
        content = UILabel(frame: CGRect(x: 0, y: height/6.5, width: width, height: height*0.7))
        title = UILabel(frame: CGRect(x: 0, y: content.frame.maxY-(height/6.5), width: width, height: height*0.3))
        
        content.setupLabel(color: .lightBlack, fitFont: false, fontWeight: .Bold, fontSize: width/5.5)
        title.setupLabel(color: .myGray, fitFont: false, fontWeight: .Regular, fontSize: width/7.8)
        
        addSubview(content)
        addSubview(title)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
}
