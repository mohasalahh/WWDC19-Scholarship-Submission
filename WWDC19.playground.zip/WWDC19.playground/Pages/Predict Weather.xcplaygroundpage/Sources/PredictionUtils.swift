//
//  PredictionUtils.swift
//  This class is used to initlize and use CoreML Models to predict weather.
//
//  WWDC19
//
//  Created by Mohamed Salah on 15/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//
//  Inspired from the xcode auto-generated CoreML code.

import CoreML

class PredictionUtils {
    
    // Singleton:
    static let shared = PredictionUtils()
    private var cache = [String: Weather]()
    
    private init() { }
    
    /**
     The main function of generating Weather object by prediction.
     - parameters:
     - date: target date (dd.mm hh)
     - city: the specific city code to predict
     */
    func getWeather(date: String, city: String)-> Weather {
        // Check for cached weather
        if let cached = cache[date+city] {
            return cached
        } else {
            // Predicting main temperature according to date
            let temperatureDic = getOutput(featureNames: ["Time&City"],
                                           inputs: ["Time&City": date as AnyObject],
                                           type: "Temperature",
                                           city: city,
                                           outputName: "Temperature") as! [AnyObject]
            var temperature = temperatureDic[0]
            
            // Prediciton accuracy of the temperature sorted from the greatest to the lowest
            let probabilityDic = Array((temperatureDic[1] as! [Int: Double])).sorted {$0.value > $1.value}
            var prob = probabilityDic[0].value
            var tempAll = temperature as! Int
            var divisor = 1
            
            // Getting the mean value of the best predicted temperatures:
            for i in 1..<3 {
                if probabilityDic[i].value > 0.15 {
                    if i == 1 || i == 2 {
                        prob += probabilityDic[i].value
                    }
                    tempAll += probabilityDic[i].key
                    divisor += 1
                }
            }
            
            temperature = (tempAll/divisor) as AnyObject
            // All these values are built over each other by predicting.
            let dewTemperature = getOutput(featureNames: ["Temperature"],
                                           inputs: ["Temperature": temperature],
                                           type: "DewTemperature",
                                           city: city,
                                           outputName: "Dewpoint")
            let pressure = getOutput(featureNames: ["Temperature", "Dewpoint"],
                                     inputs: ["Temperature": temperature, "Dewpoint": dewTemperature],
                                     type: "Pressure",
                                     city: city,
                                     outputName: "Pressure")
            let visibility = getOutput(featureNames: ["Temperature", "Dewpoint", "Pressure"],
                                       inputs: ["Temperature": temperature, "Dewpoint": dewTemperature, "Pressure": pressure],
                                       type: "Visibility",
                                       city: city,
                                       outputName: "Visibility")
            let windSpeed = getOutput(featureNames: ["Temperature", "Dewpoint", "Pressure", "Visibility"],
                                      inputs: ["Temperature": temperature, "Dewpoint": dewTemperature, "Pressure": pressure, "Visibility": visibility],
                                      type: "Wind",
                                      city: city,
                                      outputName: "Wind Speed")
            
        
            
            
            let finalWeather = Weather(temp: temperature as! Int,
                                       probability: Int(prob*100),
                                       humidity: calculateHumidity(from: temperature as! Double, and: dewTemperature as! Double),
                                       pressure: Int((pressure as! Double)/0.75), // Convert mm Hg to hPa
                visibility: (visibility as! Double).rounded(toPlaces: 1),
                windSpeed: (windSpeed as! Double).rounded(toPlaces: 1))
            
            // Cache data for future uses
            cache[date+city] = finalWeather
            return finalWeather
        }
    }
    
    /**
     Get specific prediction type.
     - parameters:
     - featureNames: names of the inputs
     - inputs: inputs data
     - type: prediction type
     - city: the specific city code to predict
     - outputName: the specific prediction name output
     */
    private func getOutput(featureNames: Set<String>,
                           inputs: [String: AnyObject],
                           type: String,
                           city: String,
                           outputName: String)-> AnyObject {
        
        let model = PredictionModel(type: type, city: city)
        guard let prediction = try? model.prediction(featureNames: featureNames, inputs: inputs) else {
            fatalError("Unexpected runtime error.")
        }
        
        return prediction.outputs[outputName]!
    }
    
    /**
     Calculate predicted Humidity using Vapor Pressure.
     *Calculations are based on: http://andrew.rsmas.miami.edu/bmcnoldy/Humidity.html
     - parameters:
     - temperature: predicted temperature
     - dewTemperature: predicted dewpoint temperature
     */
    private func calculateHumidity(from temperature: Double, and dewTemperature: Double)-> Int {
        return Int(100*(exp((17.625*dewTemperature)/(243.04+dewTemperature))/exp((17.625*temperature)/(243.04+temperature))))
    }
    
    
    // Model Prediction Input Type
    private class PredictionModelInput : MLFeatureProvider {
        var featureNames: Set<String>
        var inputs: [String: AnyObject] = [String: AnyObject]()
        
        // Get features values = input values
        func featureValue(for featureName: String) -> MLFeatureValue? {
            if (featureName == "Time&City") {
                return MLFeatureValue(string: inputs["Time&City"] as! String)
            }else if (featureName == "Temperature") {
                return MLFeatureValue(double: inputs["Temperature"] as! Double)
            }else if (featureName == "Pressure") {
                return MLFeatureValue(double: inputs["Pressure"] as! Double)
            }else if (featureName == "Visibility") {
                return MLFeatureValue(double: inputs["Visibility"] as! Double)
            }else if (featureName == "Dewpoint") {
                return MLFeatureValue(double: inputs["Dewpoint"] as! Double)
            }
            return nil
        }
        
        init(featureNames: Set<String>, inputs: [String: AnyObject]) {
            self.featureNames = featureNames
            self.inputs = inputs
        }
    }
    
    // Model Prediction Output Type
    private class PredictionModelOutput : MLFeatureProvider {
        
        private let provider : MLFeatureProvider
        var outputs: [String: AnyObject] = [String: AnyObject]()
        
        var featureNames: Set<String> {
            return self.provider.featureNames
        }
        
        func featureValue(for featureName: String) -> MLFeatureValue? {
            return self.provider.featureValue(for: featureName)
        }
        
        init(features: MLFeatureProvider) {
            self.provider = features
            // Outputs init
            if let n = provider.featureValue(for: "Dewpoint") {
                outputs["Dewpoint"] = n.doubleValue as AnyObject
            }else if let n = provider.featureValue(for: "Temperature") {
                outputs["Temperature"] = [n.int64Value as AnyObject, provider.featureValue(for: "TemperatureProbability")!.dictionaryValue as AnyObject] as AnyObject
            }else if let n = provider.featureValue(for: "Pressure") {
                outputs["Pressure"] = n.doubleValue as AnyObject
            }else if let n = provider.featureValue(for: "Visibility") {
                outputs["Visibility"] = n.doubleValue as AnyObject
            }else if let n = provider.featureValue(for: "Wind Speed") {
                outputs["Wind Speed"] = n.doubleValue as AnyObject
            }
        }
    }
    
    
    // Class for model loading and prediction
    private class PredictionModel {
        var model: MLModel
        
        /**
         Construct a model of specific type and city
         - parameters:
         - type: prediction type
         - city: the specific city code to predict
         */
        init(type: String, city: String) {
            self.model = try!MLModel(contentsOf: Bundle.main.url(forResource: type+"PredictionModel"+city, withExtension: "mlmodelc")!)
        }
        
        /**
         Make a prediction using the structured interface
         - parameters:
         - input: the input to the prediction as PredictionModelInput
         - throws: an NSError object that describes the problem
         - returns: the result of the prediction as PredictionModelOutput
         */
        func prediction(input: PredictionModelInput) throws -> PredictionModelOutput {
            return try self.prediction(input: input, options: MLPredictionOptions())
        }
        
        /**
         Make a prediction using the structured interface
         - parameters:
         - input: the input to the prediction as PredictionModelInput
         - options: prediction options
         - throws: an NSError object that describes the problem
         - returns: the result of the prediction as PredictionModelOutput
         */
        func prediction(input: PredictionModelInput,
                        options: MLPredictionOptions) throws -> PredictionModelOutput {
            let outFeatures = try model.prediction(from: input, options:options)
            return PredictionModelOutput(features: outFeatures)
        }
        
        /**
         Make a prediction using the convenience interface
         - parameters:
         - featureNames: feature names for the specific model
         - inputs: specific inputed data
         - throws: an NSError object that describes the problem
         - returns: the result of the prediction as PredictionModelOutput
         */
        func prediction(featureNames: Set<String>,
                        inputs: [String: AnyObject]) throws -> PredictionModelOutput {
            let input_ = PredictionModelInput(featureNames: featureNames, inputs: inputs)
            return try self.prediction(input: input_)
        }
    }
    
}
