//
//  MainView.swift
//  This class is used to initlize the main view that includes all the other views.
//
//  WWDC19
//
//  Created by Mohamed Salah on 15/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//

import UIKit

public class MainView: UIView {
    
    var viewHeight: CGFloat = 0
    var viewWidth: CGFloat = 0
    
    var sideBarTableView: SideBarTableView!
    var sideBarBtn: UIButton!
    
    var overlayView: UIView!
    
    var cityLabel: UILabel!
    var dateLabel: UILabel!
    
    var mainTempLabel: UILabel!
    var secTempLabel: UILabel!
    
    var weatherCollection: WeatherDataCollectionView!
    var graphTable: GraphTableView!
    var daysCollection: DaysCollectionView!
    
    var cityN = ""
    
    let dateFormatter = DateFormatter()
    
    public init(height: CGFloat) {
        super.init(frame: CGRect(x: 0, y: 0, width: height*0.55, height: height))
        
        // Registering our fonts
        CTFontManagerRegisterFontsForURL(Bundle.main.url(forResource: "Aleo-Regular", withExtension: "otf")! as CFURL, CTFontManagerScope.process, nil)
        CTFontManagerRegisterFontsForURL(Bundle.main.url(forResource: "Aleo-Bold", withExtension: "otf")! as CFURL, CTFontManagerScope.process, nil)
        
        viewHeight = frame.height
        viewWidth = frame.width
        
        backgroundColor = .white
        
        // Adding circles decorations
        for i in 1..<5 {
            let firstCircleW = (viewWidth/1.4)
            let circleWidth = firstCircleW*pow(1.2, CGFloat(i-1))
            let path = UIBezierPath(ovalIn: CGRect(x: -firstCircleW/3, y: -firstCircleW/3, width: circleWidth, height: circleWidth))
            
            let circle = CAShapeLayer()
            circle.path = path.cgPath
            circle.fillColor = UIColor(red: 231, green: 238, blue: 255, alph: 0.75-(CGFloat(i)*0.2)).cgColor
            layer.insertSublayer(circle, at: 1)
            
        }
        
        let margin20th = viewWidth/20
        let margin35th = viewHeight/35
        
        sideBarTableView = SideBarTableView(frame: CGRect(x: -viewWidth/1.4, y: 0, width: viewWidth/1.4, height: viewHeight))
        sideBarBtn = UIButton(frame: CGRect(x: margin20th, y: margin20th, width: viewWidth/17, height: viewWidth/17))
        
        overlayView = UIView(frame: bounds)
        
        cityLabel = UILabel(frame: CGRect(x: margin20th, y: margin20th, width: viewWidth-(margin20th*2), height: viewHeight/16))
        dateLabel = UILabel(frame: CGRect(x: margin20th, y: cityLabel.frame.maxY, width: cityLabel.frame.width, height: cityLabel.frame.height/2.1))
        
        mainTempLabel = UILabel(frame: CGRect(x: margin20th, y: dateLabel.frame.maxY+margin35th, width: cityLabel.frame.width, height: cityLabel.frame.height*2))
        secTempLabel = UILabel(frame: CGRect(x: margin20th, y: mainTempLabel.frame.maxY, width: cityLabel.frame.width, height: dateLabel.frame.height*1.6))
        
        weatherCollection = WeatherDataCollectionView(frame: CGRect(x: margin20th, y: secTempLabel.frame.maxY+margin35th, width: cityLabel.frame.width, height: viewHeight/5))
        
        let daysWidth = ((viewHeight/18)+(viewHeight/18/8))*7
        daysCollection = DaysCollectionView(frame: CGRect(x: (viewWidth/2)-(daysWidth/2), y: viewHeight-20-(viewHeight/18), width: daysWidth, height: viewHeight/18))
        
        let graphHeight = (daysCollection.frame.minY-weatherCollection.frame.maxY)*0.85
        graphTable = GraphTableView(frame: CGRect(x: margin20th, y:
            weatherCollection.frame.maxY+(graphHeight*0.06375), width: cityLabel.frame.width, height: graphHeight))
        
        sideBarBtn.setImage(UIImage(named: "menu.png"), for: .normal)
        sideBarBtn.addTarget(self, action: #selector(showSideBar), for: .touchUpInside)
        
        overlayView.backgroundColor = .black
        overlayView.alpha = 0
        overlayView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(hideSideBar)))
        
        // Setting up labels made easy through a simple extension.
        cityLabel.setupLabel(color: .colorMain, fitFont: true, fontWeight: .Bold)
        dateLabel.setupLabel(color: .colorMain, fitFont: true, fontWeight: .Regular)
        
        mainTempLabel.setupLabel(color: .colorMain, fitFont: true, fontWeight: .Bold)
        secTempLabel.setupLabel(color: .colorMain, fitFont: true, fontWeight: .Regular)
        
        addSubview(sideBarBtn)
        
        addSubview(cityLabel)
        addSubview(dateLabel)
        
        addSubview(mainTempLabel)
        addSubview(secTempLabel)
        
        addSubview(weatherCollection)
        addSubview(graphTable)
        addSubview(daysCollection)
        
        addSubview(overlayView)
        addSubview(sideBarTableView)
        
        // Panning gesture for sideBar.
        addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(handlePan(gesture:))))
        
        reloadData(city: "SF")
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func showSideBar() {
        UIView.animate(withDuration: 0.3, delay: 0, options: [.curveEaseInOut], animations: {
            self.sideBarTableView.frame.origin.x = 0
            self.sideBarTableView.alpha = 1
            self.overlayView.alpha = 0.5
        }, completion: nil)
        
    }
    @objc func hideSideBar() {
        UIView.animate(withDuration: 0.3, delay: 0, options: [.curveEaseInOut], animations: {
            self.sideBarTableView.frame.origin.x = -self.sideBarTableView.frame.width
            self.sideBarTableView.alpha = 0
            self.overlayView.alpha = 0
        }, completion: nil)
        
    }
    
    @objc func handlePan(gesture: UIPanGestureRecognizer) {
        if gesture.state == .changed {
            let xValue = gesture.translation(in: self).x+sideBarTableView.frame.origin.x
            // Check if the new position is within the sideBar limits.
            if xValue <= 0 && xValue >= -sideBarTableView.frame.width {
                let percent = abs(xValue)/sideBarTableView.frame.width // How long in % you dragged the sideBar from its resting position.
                
                // Making panning interactive
                overlayView.alpha = 0.5-(0.5*percent)
                sideBarTableView.alpha = 1-percent
                
                sideBarTableView.frame.origin.x = xValue
                
                // Resetting the translation
                gesture.setTranslation(CGPoint.zero, in: self)
            }
        }else if gesture.state == .ended {
            let velocityX = gesture.velocity(in: self).x
            // Check for the velocity direction, so that when the dragging ends the sideBar must rest into the starting or the ending position depending on the direction
            if velocityX > 0 {
                showSideBar()
            }else {
                hideSideBar()
            }
        }
    }
    
    /**
     Reload view's information with specific city predictions.
     - parameters:
     - city: the specific city code to predict
     - days: an optional paramter used for updating according to DaysCollectionView
     */
    public func reloadData(city: String, days: Int = 0) {
        cityN = city
        
        let currentDate = Date().addingTimeInterval(TimeInterval(days*86400))
        let timeZone = cityTimezone(city)
        var weatherObjects = [Weather]()
        
        var graphData: [[Double]] = [[], []]
        
        dateFormatter.timeZone = TimeZone(secondsFromGMT: timeZone*3600)
        dateFormatter.dateFormat = "dd.MM HH"
        
        // Predict the weather of 6 hours period.
        for i in 0..<7 {
            weatherObjects.append(PredictionUtils.shared.getWeather(date: dateFormatter.string(from: currentDate.addingTimeInterval(TimeInterval(i*3600))), city: city))
            // Adding info to the graph data
            graphData[0].append(Double(weatherObjects[i].temp))
            graphData[1].append(Double(weatherObjects[i].humidity))
        }
        
        let currentWeather = weatherObjects[0]
        
        dateFormatter.dateFormat = "EEEE | MMM d | HH:mm"
        
        cityLabel.text = cityFullName(city)
        dateLabel.text = dateFormatter.string(from: currentDate)
        
        mainTempLabel.text = String(currentWeather.temp)+"°C"
        secTempLabel.text = String(Int(graphData[0].min()!))+"~"+String(Int(graphData[0].max()!)) //TODO
        
        // Update the weather data
        weatherCollection.data = [
            [
                String(currentWeather.pressure)+" hPa",
                String(currentWeather.windSpeed)+" m/s",
                String(currentWeather.visibility)+" km"
            ], [
                String(currentWeather.humidity)+" %",
                String(currentWeather.probability)+" %"
            ]
        ]
        
        // Update the graph
        graphTable.timeZoneGMT = timeZone
        graphTable.data = graphData
        graphTable.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: false)
        
        // Update the days according to the city's timeZone
        daysCollection.timeZoneGMT = timeZone
    }
    
    /**
     Called from the DaysCollectionView to update the weather of a specific day in week.
     - parameters:
     - days: number of days from now
     */
    func selectDay(days: Int) {
        reloadData(city: cityN, days: days)
    }
}
