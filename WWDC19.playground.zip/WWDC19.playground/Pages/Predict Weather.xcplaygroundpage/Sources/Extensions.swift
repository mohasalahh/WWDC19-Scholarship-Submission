//
//  Extensions.swift
//  This class manages global extensions that simplify things up.
//
//  WWDC19
//
//  Created by Mohamed Salah on 15/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//

import UIKit

 extension UIColor {
    //used for clarity
     convenience init(red: CGFloat, green: CGFloat, blue: CGFloat) {
        self.init(red: red / 255.0, green: green / 255.0, blue: blue / 255.0, alpha: 1.0)
    }
     convenience init(red: CGFloat, green: CGFloat, blue: CGFloat, alph: CGFloat) {
        self.init(red: red / 255.0, green: green / 255.0, blue: blue / 255.0, alpha: alph)
    }
    
    // Colors used in the playground
    static var colorMain: UIColor {
        return UIColor(red: 93, green: 117, blue: 245)
    }
    static var colorMainLight: UIColor {
        return UIColor(red: 111, green: 132, blue: 246)
    }
    static var lightBlack: UIColor {
        return UIColor(red: 15, green: 15, blue: 15)
    }
    static var myGray: UIColor {
        return UIColor(red: 174, green: 174, blue: 174)
    }
}

 extension Array where Element == CGPoint {
    // Algorithm used to convert graph points to smooth curvy lines.
    // Credits: https://stackoverflow.com/a/25289762/4724060
    func getCurvedFromStraight() -> UIBezierPath {
        let path = UIBezierPath()
        var p1: CGPoint = self[0]
        path.move(to: p1)
        
        for i in 0..<self.count {
            let p2: CGPoint = self[i]
            let midPoint: CGPoint = midPointWithPoint(p1: p1, p2: p2)
            path.addQuadCurve(to: midPoint, controlPoint: controlPointForPoints(p1: midPoint, p2: p1))
            path.addQuadCurve(to: p2, controlPoint: controlPointForPoints(p1: midPoint, p2: p2))
            p1 = p2
        }
        
        return path
    }
    
    private func controlPointForPoints(p1: CGPoint, p2: CGPoint) -> CGPoint {
        var controlPoint: CGPoint = midPointWithPoint(p1: p1, p2: p2)
        let diffY: CGFloat = abs(p2.y - controlPoint.y)
        
        if p1.y < p2.y {
            controlPoint.y += diffY
        } else if p1.y > p2.y {
            controlPoint.y -= diffY
        }
        
        return controlPoint
    }
    
    private func midPointWithPoint(p1: CGPoint, p2: CGPoint) -> CGPoint {
        return CGPoint(x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2)
    }
}

 extension UILabel {
    // Simple Extension to simplify setting labels' styles
     func setupLabel(color: UIColor, fitFont: Bool, fontWeight: FontWeight, fontSize: CGFloat? = nil, alignment: NSTextAlignment = .center) {
        textColor = color
        textAlignment = alignment
        
        // Used for safety
        adjustsFontSizeToFitWidth = true
        numberOfLines = 0
        
        if fitFont {
            font = UIFont(name: "Aleo-"+fontWeight.description, size: 100)
        }else {
            font = UIFont(name: "Aleo-"+fontWeight.description, size: fontSize!)
        }
    }
}

 extension Double {
    // Round a double value to nearest places.
     func rounded(toPlaces places: Int)-> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
}
