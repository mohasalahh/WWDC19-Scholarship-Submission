//
//  SideBarTableView.swift
//  This class is resposible for generating a TableView that is used to show available cities to predict.
//
//  WWDC19
//
//  Created by Mohamed Salah on 19/3/19.
//  Copyright © 2019 Mohamed Salah. All rights reserved.
//

import UIKit

class SideBarTableView: UITableView, UITableViewDelegate, UITableViewDataSource {
    
    // Cities
    final let cities = ["SF", "BA", "HK", "DU", "CA"]
    final let countries = ["USA", "Thailand", "China", "UAE", "Egypt"]
    
    let dateFormatter = DateFormatter()
    let dateFormatter2 = DateFormatter()
    
    init(frame: CGRect) {
        super.init(frame: frame, style: .grouped)
        
        dataSource = self
        delegate = self
        
        showsVerticalScrollIndicator = false
        separatorColor = .clear
        backgroundColor = .white
        
        dateFormatter.dateFormat = "HH:mm"
        dateFormatter2.dateFormat = "dd.MM HH"
        
        register(SideBarTableViewCell.self, forCellReuseIdentifier: "cell")
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! SideBarTableViewCell
        let row = indexPath.row
        
        // Applying timeZone to the DateFormatters
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 3600*cityTimezone(cities[row]))
        dateFormatter2.timeZone = dateFormatter.timeZone
        
        cell.cityLabel.text = cityFullName(cities[row])
        cell.timeLabel.text = dateFormatter.string(from: Date())
        cell.countryLabel.text = countries[row]
        
        // Predict the current temperature for the specific city
        cell.tempLabel.text = String(PredictionUtils.shared.getWeather(date: dateFormatter2.string(from: Date()), city: cities[row]).temp)+"°C"
        
        return cell
    }
    
    var selected = 0
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Scroll
        (superview as! MainView).daysCollection.resetSelection()
        // Hide the sideBar and reload the data for the specific city
        (superview as! MainView).hideSideBar()
        if selected != indexPath.row {
            (superview as! MainView).reloadData(city: cities[indexPath.row])
            selected = indexPath.row
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        // Adding the header, which is my logo
        let logo = UIImageView(frame: CGRect(x: 0, y: frame.height/30, width: frame.width, height: frame.height/20))
        logo.contentMode = .scaleAspectFit
        logo.image = UIImage(named: "logo.png")
        logo.alpha = 0.3
        // Used for margins and centering
        let containerView = UIView(frame: CGRect(x: 0, y: 0, width: frame.width, height: frame.height/20))
        containerView.addSubview(logo)
        return containerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return (frame.height/20)+((frame.height/30)*2)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // Ratio of width:height = 229:140
        return (frame.width*140)/229
    }
    
}

class SideBarTableViewCell: UITableViewCell {
    
    var containerView = UIView()
    
    var cityLabel = UILabel()
    var timeLabel = UILabel()
    var countryLabel = UILabel()
    
    var tempLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none // Avoid selection color
        
        // Adding Views to the cardView
        containerView.addSubview(cityLabel)
        containerView.addSubview(countryLabel)
        containerView.addSubview(timeLabel)
        
        containerView.addSubview(tempLabel)
        
        addSubview(containerView)
    }
    
    var once = true
    override func layoutSubviews() {
        super.layoutSubviews()
        if once {
            once = false
            
            // Add margins to the cardView.
            containerView.frame = contentView.bounds.inset(by: UIEdgeInsets(top: contentView.frame.width/12/2, left: contentView.frame.width/12/2, bottom: contentView.frame.width/12/2, right: contentView.frame.width/12/2))
            
            let containerWidth = containerView.frame.width
            let containerHeight = containerView.frame.height
            
            // Main card bg path
            let shadowedBGLayerPath = UIBezierPath(roundedRect: containerView.bounds, cornerRadius: containerWidth/15).cgPath
            
            // Main Layer
            let shadowedBGLayer = CAShapeLayer()
            shadowedBGLayer.path = shadowedBGLayerPath
            shadowedBGLayer.fillColor = UIColor.white.cgColor
            
            shadowedBGLayer.shadowColor = UIColor.black.cgColor
            shadowedBGLayer.shadowOpacity = 0.15
            shadowedBGLayer.shadowOffset = CGSize(width: 0, height: 1)
            shadowedBGLayer.shadowRadius = 7
            
            // Layer that holds the circles decorations and is also masked by the layer below
            let maskLayer = CAShapeLayer()
            maskLayer.path = shadowedBGLayerPath
            maskLayer.fillColor = UIColor.clear.cgColor
            // Not working and I don't know the reason!
            // maskLayer.masksToBounds = true
            // So I'm using another layer as a mask
            let maskLayer2 = CAShapeLayer()
            maskLayer2.path = shadowedBGLayerPath
            // Applying mask to the layer
            maskLayer.mask = maskLayer2
            
            // Adding circle decorations
            for i in 1..<5 {
                let firstCircleW = (containerWidth/2.5)
                let circleWidth = firstCircleW*pow(1.2, CGFloat(i-1))
                let path = UIBezierPath(ovalIn: CGRect(x: -firstCircleW/3, y: -firstCircleW/3, width: circleWidth, height: circleWidth))
                
                let circle = CAShapeLayer()
                circle.path = path.cgPath
                circle.fillColor = UIColor(red: 231, green: 238, blue: 255, alph: 0.68-(CGFloat(i)*0.15)).cgColor
                maskLayer.addSublayer(circle)
                
            }
            
            shadowedBGLayer.addSublayer(maskLayer)
            containerView.layer.insertSublayer(shadowedBGLayer, at: 0)
            
            cityLabel.frame = CGRect(x: containerWidth/10, y: containerWidth/20, width: containerWidth-((containerWidth/10)*2), height: containerHeight/3)
            
            timeLabel.frame = CGRect(x: cityLabel.frame.minX, y: cityLabel.frame.maxY, width: containerWidth/2.8, height: containerHeight/6)
            countryLabel.frame = CGRect(origin: CGPoint(x: cityLabel.frame.minX, y: timeLabel.frame.maxY), size: timeLabel.frame.size)
            
            tempLabel.frame = CGRect(x: cityLabel.frame.maxX-(containerWidth/2), y: cityLabel.frame.maxY+(containerWidth/25), width: containerWidth/2, height: containerHeight-(cityLabel.frame.maxY)-((containerWidth/25)*2))
            
            // Setting labels' styles
            cityLabel.setupLabel(color: .colorMain, fitFont: false, fontWeight: .Bold, fontSize: containerWidth/8, alignment: .left)
            timeLabel.setupLabel(color: .colorMain, fitFont: false, fontWeight: .Regular, fontSize: containerWidth/14.4, alignment: .left)
            countryLabel.setupLabel(color: .colorMain, fitFont: false, fontWeight: .Regular, fontSize: containerWidth/14.4, alignment: .left)
            
            tempLabel.setupLabel(color: .colorMain, fitFont: false, fontWeight: .Bold, fontSize: containerWidth/5.4, alignment: .right)
            
        }
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
}
