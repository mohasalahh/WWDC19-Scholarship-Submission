/*:
 - Important:
 **Training and generating a CoreML model requires a MacOS target playground, so this playgroundpage won't run; instead, it only shows you how the process is done.**
 
 - Note:
 All previous weather data are exported from [`Reliable Prognosis`](https://rp5.ru), a website that provides free archived weather data over years.
 
 - Note:
 This templete is based on Creating-Module-From-tabular-data playground from the official docs.
 
 # Training CoreML Models
 ### PlaygroundPage that trains CoreML Models to predict weather in a specific city
 ****
 
 ## Overview
 This sample playground uses the
 [CreateML](https://developer.apple.com/documentation/createml)
 framework to train
 [CoreML](https://developer.apple.com/documentation/coreml)
 models of types regressors and classifiers.
 
 The playground imports data as CSV files, which contain previous weather data for a specific city, into a data table.
 The data table contains the following columns of information about the weather of the specific city:
 
 - `Time&City (dd.MM HH)`
 - `Temperature (°C)`
 - `Pressure (hPa)`
 - `Wind Speed (m/s)`
 - `Visibility (km)`
 - `Dewpoint (°C)`
 
 The playground trains the regressor and classifier models, each with a group of columns relevant to that model.
 Once trained, the classifier is ready to predict the temperature based on previous data from the same time, and the regressor is ready to predict values(Dewpoint, Pressure, Wind Speed, or Visibility) based on other numerical values.
 
 The playground will then save the final models in the desktop.
 
 ## Import the Data
 Use any
 [`MLDataTable`](https://developer.apple.com/documentation/createml/mldatatable)
 initializer to import your data in to a data table.
 In this sample, the playground will initializes a small sample of previous weather data in San Francisco.
 
 ````
 import Foundation
 import CreateML

 let csvFile = Bundle.main.url(forResource: "SFPreviousData", withExtension: "csv")!
 let dataTable = try MLDataTable(contentsOf: csvFile)
 ````
 
 - Note:
 The original CSV file is not included in this playground due to size limits; instead, a sample size of the weather of one day is attached.
 ## Isolate the Relevant Model Data
 Generate a new data table that includes only relevant columns for your model.
 
 To predict the temperature, the playground’s classifier needs only 2 columns:
 
 - `Time&City`
 - `Temperature`
 
 The playground generates a new data table, specifically tailored for the classifier, by passing an array of column names to first data table’s
 [`subscript(_:)`](https://developer.apple.com/documentation/createml/mldatatable/3022554-subscript).

 ````
 let classifierColumns = ["Time&City", "Temperature"]
 let classifierTable = dataTable[classifierColumns]
 ````

 To predict dewpoint, which is predicted through a regressor, the regressor only needs:
 
 - `Temperature`
 - `Dewpoint`

 ````
 let regressorColumns = ["Temperature", "Dewpoint"]
 let regressorTable = dataTable[regressorColumns]
 ````

 ## Train the Classifier
 The playground trains the classifier by providing its initializer with the training data table and the name of the target column.
 The `targetColumn` parameter determines what information you want the model to provide in its predictions.
 The playground tells the classifier to predict the temperature based on a specific date.
 
 ````
 let classifier = try MLClassifier(trainingData: classifierTable, targetColumn: "Temperature")
 ````
 
 ## Train the Regressor
 The playground trains the regressor to predict several numerical values related to the temperature.
 It does so by targeting a regressor on the `Dewpoint`, or the specified output, column of its training data table.
 
 ````
 let regressor = try MLRegressor(trainingData: classifierTrainingTable, targetColumn: "Dewpoint")
 ````
 
 ## Save the Model
 Finally, we will save the two models, along with metadata, to the user’s desktop with its
 [`write(to:metadata:)`](https://developer.apple.com/documentation/createml/mlregressor/3006686-write)
 method.

 ````
 let homePath = FileManager.default.homeDirectoryForCurrentUser
 let desktopPath = homePath.appendingPathComponent("Desktop")

 let classifierMetadata = MLModelMetadata(author: "Mohamed Salah",
                                       shortDescription: "Predicts the Temeprature in San Francisco.",
                                       version: "1.0")
 try classifier.write(to: desktopPath.appendingPathComponent("TemperaturePredictionModelSF.mlmodel"),
                      metadata: classifierMetadata)
 ````
 
 The playground similarly saves the Dewpoint regressor to the user’s desktop.
 
 ````
 let regressorMetadata = MLModelMetadata(author: "Mohamed Salah",
                                      shortDescription: "Predicts the Dewpoint Temperature in San Francisco.",
                                      version: "1.0")
 Save the trained regressor model to the Desktop.
 try regressor.write(to: desktopPath.appendingPathComponent("DewTemperaturePredictionModelSF.mlmodel"),
                     metadata: regressorMetadata)
 ````
    
 ****
  [Table of Contents](Table%20of%20Contents) | [Predict Weather](@next)
 */
